const jwt = require("jsonwebtoken")

module.exports = (req, res, next) => {
  const token = req.header("Authorization")?.replace("Bearer ", "")
  if (!token) return res.status(401).json({ error: "Access Denied" })

  try {
    const verified = jwt.verify(token, "SECRET_KEY")
    req.user = verified
    next()
  } catch (err) {
    res.status(400).json({ error: "Invalid Token" })
  }
}
