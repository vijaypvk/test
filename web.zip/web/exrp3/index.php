<?php
require_once "phpqrcode/qrlib.php";

$qrFile = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $text = trim($_POST['text']);
    if (!empty($text)) {
        $qrFile = 'qr.png';
        QRcode::png($text, $qrFile);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Text to QR Code</title>
  <style>
    body {
      font-family: sans-serif;
      text-align: center;
      padding: 40px;
    }
    input {
      padding: 10px;
      width: 250px;
    }
    button {
      padding: 10px 20px;
    }
  </style>
</head>
<body>

  <h2>Generate QR Code from Text</h2>

  <form method="POST">
    <input type="text" name="text" placeholder="Enter text" required>
    <button type="submit">Generate QR</button>
  </form>

  <?php if ($qrFile): ?>
    <h3>QR Code:</h3>
    <img src="<?php echo $qrFile; ?>" alt="QR Code">
  <?php endif; ?>

</body>
</html>
