from flask import Flask, render_template, request

app = Flask(__name__)

# Store messages (simple in-memory storage)
messages = []

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        user_message = request.form['message']
        messages.append(user_message)  # Add user message to chat
    return render_template('index.html', messages=messages)

if __name__ == '__main__':
    app.run(debug=True)
