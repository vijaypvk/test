from flask import Flask, render_template, request, redirect

app = Flask(__name__)

# In-memory task list
tasks = []

@app.route('/')
def index():
    return render_template('index.html', tasks=tasks)

@app.route('/add', methods=['POST'])
def add():
    title = request.form['title']
    tasks.append({'title': title, 'status': 'To Do'})
    return redirect('/')

@app.route('/update/<int:task_id>/<status>')
def update(task_id, status):
    if 0 <= task_id < len(tasks):
        tasks[task_id]['status'] = status
    return redirect('/')

if __name__ == '__main__':
    app.run(debug=True)
