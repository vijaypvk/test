from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS  # Import CORS

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///bank.db'
db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password = db.Column(db.String(50), nullable=False)
    balance = db.Column(db.Float, default=0.0)

@app.route('/register', methods=['POST'])
def register():
    data = request.json
    user = User(username=data['username'], password=data['password'])
    db.session.add(user)
    db.session.commit()
    return jsonify({"message": "Registered successfully"})

@app.route('/balance/<username>', methods=['GET'])
def balance(username):
    user = User.query.filter_by(username=username).first()
    return jsonify({"balance": user.balance if user else "User not found"})

@app.route('/deposit', methods=['POST'])
def deposit():
    data = request.json
    user = User.query.filter_by(username=data['username']).first()
    if user:
        user.balance += data['amount']
        db.session.commit()
        return jsonify({"message": "Deposit successful"})
    return jsonify({"message": "User not found"})

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)