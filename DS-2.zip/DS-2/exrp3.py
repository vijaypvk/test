# Input number of vertices and edges
n = int(input("No. of vertices: "))
e = int(input("No. of edges: "))

# Input edges
edges = []
for _ in range(e):
    u, v, w = map(int, input("Enter edge (u v w): ").split())
    edges.append((u, v, w))

# Union-Find (Disjoint Set)
parent = list(range(n))

def find(x):
    if parent[x] != x:
        parent[x] = find(parent[x])  # Path compression
    return parent[x]

def union(x, y):
    parent[find(x)] = find(y)

# Kruskal's Algorithm
mst = []
edges.sort(key=lambda x: x[2])  # Sort by weight

for u, v, w in edges:
    if find(u) != find(v):
        union(u, v)
        mst.append((u, v, w))

# Output MST
print("MST edges:", mst)
