class City:
    def __init__(self, name, x, y):
        self.name = name
        self.x = x
        self.y = y

# Input cities
cities = []
n = int(input("No. of cities: "))
for _ in range(n):
    name, x, y = input("Enter city name and (x y): ").split()
    cities.append(City(name, int(x), int(y)))

# Location to search
x, y = map(int, input("Search location (x y): ").split())

# Search
found = False
for city in cities:
    if city.x == x and city.y == y:
        print("City found:", city.name)
        found = True
        break

if not found:
    print("City not found")
