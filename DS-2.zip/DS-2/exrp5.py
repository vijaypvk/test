# Input data
data = list(map(int, input("Enter numbers: ").split()))
n = len(data)

# Build the segment tree
tree = [0] * (2 * n)
for i in range(n):
    tree[n + i] = data[i]
for i in range(n - 1, 0, -1):
    tree[i] = tree[2 * i] + tree[2 * i + 1]

# Range sum query
l, r = map(int, input("Enter range (l r): ").split())
res = 0
l += n
r += n
while l < r:
    if l % 2 == 1:
        res += tree[l]
        l += 1
    if r % 2 == 1:
        r -= 1
        res += tree[r]
    l //= 2
    r //= 2

print("Range Sum:", res)
