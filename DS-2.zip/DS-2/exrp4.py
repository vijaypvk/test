def print_board(board):
    for row in board:
        print(' '.join(row))
    print()

def is_valid_move(board, start, end, player):
    piece = board[start[0]][start[1]]
    if piece == '.':
        return False
    if player == 'W' and piece.islower():
        return False
    if player == 'B' and piece.isupper():
        return False
    target_piece = board[end[0]][end[1]]
    if player == 'W' and target_piece.isupper():
        return False
    if player == 'B' and target_piece.islower():
        return False
    return True

def get_position(pos):
    return (8 - int(pos[1]), ord(pos[0]) - ord('a'))

def chess_game():
    board = [
        list("rnbqkbnr"),
        list("pppppppp"),
        list("........"),
        list("........"),
        list("........"),
        list("........"),
        list("PPPPPPPP"),
        list("RNBQKBNR")
    ]

    player = 'W'

    while True:
        print_board(board)
        move_input = input(f"{player}'s move (e.g., e2 e4): ").split()
        if len(move_input) != 2:
            print("Please enter move in format 'e2 e4'")
            continue

        try:
            start = get_position(move_input[0])
            end = get_position(move_input[1])

            if is_valid_move(board, start, end, player):
                board[end[0]][end[1]] = board[start[0]][start[1]]
                board[start[0]][start[1]] = '.'
                player = 'B' if player == 'W' else 'W'
            else:
                print("Invalid move. Try again.")
        except:
            print("Invalid input! Use format like 'e2 e4'.")

chess_game()
