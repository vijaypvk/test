import heapq

graph = {}

# Input the graph
n = int(input("Number of nodes: "))
for _ in range(n):
    node = input("Node name: ")
    edges = input(f"Edges from {node} (format B:1 C:2): ").split()
    graph[node] = [(e.split(':')[0], int(e.split(':')[1])) for e in edges]

start = input("Start node: ")

# Initialization
dist = {node: float('inf') for node in graph}
dist[start] = 0
heap = [(0, start)]  # (distance, node)

# Dijkstra's Algorithm
while heap:
    d, u = heapq.heappop(heap)
    for v, w in graph[u]:
        if d + w < dist[v]:
            dist[v] = d + w
            heapq.heappush(heap, (dist[v], v))

# Output
print("Shortest distances:", dist)
