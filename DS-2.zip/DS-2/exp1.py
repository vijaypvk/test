class Trie:
    def __init__(self):
        self.root = {}

    def insert(self, word):
        node = self.root
        for c in word:
            node = node.setdefault(c, {})
        node["#"] = True  # "#" marks the end of a word

    def search(self, prefix):
        node = self.root
        for c in prefix:
            if c not in node:
                return []  # Prefix not found
            node = node[c]
        return self._collect(prefix, node)

    def _collect(self, prefix, node):
        words = []
        for c in node:
            if c == "#":
                words.append(prefix)
            else:
                words += self._collect(prefix + c, node[c])
        return words

# Input and Output
if __name__ == "__main__":
    trie = Trie()
    words = input("Enter words (space-separated): ").split()
    for word in words:
        trie.insert(word)
    prefix = input("Enter prefix: ")
    print("Autocomplete suggestions:", trie.search(prefix))
